<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='DefaultProfile' timestamp='1788279890788'>
  <properties size='5'>
    <property name='org.eclipse.equinox.p2.cache' value='/home/jenkins/agent/workspace/build_master/products/org.eclipse.oomph.setup.installer.product/target/products/org.eclipse.oomph.setup.installer.product.with-jre.restricted/linux/gtk/x86_64/eclipse-installer'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='true'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=linux,osgi.arch=x86_64,osgi.ws=gtk,osgi.nl=en_US'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='/home/jenkins/agent/workspace/build_master/products/org.eclipse.oomph.setup.installer.product/target/products/org.eclipse.oomph.setup.installer.product.with-jre.restricted/linux/gtk/x86_64/eclipse-installer'/>
  </properties>
</profile>
